# -*- coding: utf-8 -*-
"""
Created on Wed Mar 26 20:39:48 2025

@author: yubg
"""
import matplotlib.pyplot as plt

# 数据点
x = [1, 2, 3, 4]
y = [1, 4, 9, 16]
 
# 使用 plot 方法绘制曲线
plt.plot(x, y)
# 显示图形
plt.show()

plt.plot(x, y, 'r--o') #'r'表示红色，'--'表示虚线，'o'表示小圆点
plt.show()


plt.plot(x, y,
          linestyle='-',    # 实线
         linewidth=2,      # 宽度为2
          color='blue',     # 蓝色线条
          marker='d',       # 圆形标记
          markersize=5,     # 标记大小
          markerfacecolor='red',  # 标记填充颜色
          markeredgecolor='black',  # 标记边缘颜色
          alpha=0.6         # 半透明
          )
plt.show()

plt.plot(x,y,"g:D")#绿色虚线条，菱(钻石)形状点
plt.title('Asimplelineplot')#添加标题
plt.xlabel('XAxisLabel')#添加x轴标签
plt.ylabel('YAxisLabel')#添加y轴标签
plt.show()


plt.figure() # 创建一个新的图形
plt.subplot(1, 2, 1) # 创建一个 1x2 的子图，并选择第一个子图
plt.plot(x, y)
plt.subplot(1, 2, 2) # 选择第二个子图
plt.plot(y, x)
plt.show()


plt.figure(figsize=(8, 6), dpi=80)  # 宽为8, 高为6, 分辨率80dpi
plt.plot(x,y,"b-3")
plt.show()


plt.plot(x, y, label='Dataset 1')
plt.plot(y, x, label='Dataset 1')
plt.legend(title="Data Sets", fontsize=6, loc='upper center')

plt.plot(x, y, label='数据 1')
plt.plot(y, x, label='数据 1')
plt.legend(title="数据示例", fontsize='small',loc='upper center')


plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文（需安装有）
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号
plt.plot(x, y, label='数据 1')
plt.plot(y, x, label='数据 1')
plt.legend(title="数据示例", fontsize='small',loc='upper center')



import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号

# 数据
sizes = [215, 130, 245, 210]
labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'

# 突出显示 "Dogs" 部分
explode = (0, 0, 0.1, 0)  # "Dogs" 突出显示

# 自定义颜色
colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']

# 绘制饼图
plt.pie(sizes, 
        explode=explode, 
        labels=labels, 
        colors=colors, 
        autopct='%1.1f%%',
        shadow=True, 
        startangle=140)

# 显示图例
plt.legend(title="Animals")

# 设置标题
plt.title('饼图示例')

# 设置饼图的半径
plt.axis('equal')  # 确保饼图是一个完美的圆形，而不是椭圆

# 显示图形
plt.show()


import matplotlib.pyplot as plt
import numpy as np
plt.rcParams['font.sans-serif'] = ['SimHei'] # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False # 正常显示负号

# 示例数据
x = np.random.rand(50)
y = np.random.rand(50)  

#显示数据简单的散点图
plt.scatter(x,y, c='b', marker='d')
plt.savefig('d:/test2.pdf')   #将图片保存在当前的环境目录下
plt.show()



sizes = np.random.rand(50) * 1000   # 气泡大小
colors = np.random.rand(50)        # 颜色值
plt.scatter(x, y, s=sizes, c=colors, alpha=0.5, edgecolors='w', linewidth=2)
plt.title('自定义气泡图')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.show()

























