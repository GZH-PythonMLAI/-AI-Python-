# -*- coding: utf-8 -*-
"""
Created on Mon Nov  4 21:55:20 2024
第九章 胎儿健康多分类预测实现及模型评价
@author: yubg
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False
import warnings
warnings.filterwarnings("ignore")
df = pd.read_csv('FHR_data.csv')
df.head()

df.shape

from sklearn.preprocessing import LabelEncoder
# 将 y_train 的标签重新编码为从0开始的整数
label_encoder = LabelEncoder()
df['NSP(label)_encoded'] = label_encoder.fit_transform(df['NSP(label)'])

# 输出原始标签和编码后的标签
for original, encoded in zip(df['NSP(label)'], df['NSP(label)_encoded']):
    print(f"Original: {original}, Encoded: {encoded}")


# 划分特征和目标变量
X = df.drop(['NSP(label)', 'NSP(label)_encoded'], axis=1)
y = df['NSP(label)_encoded']
# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size=0.2, 
                                                    random_state=42, 
                                                    stratify=df['NSP(label)_encoded'])

#9.2.1 递归特征消除与交叉验证优化特征选择
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFECV
from sklearn.model_selection import StratifiedKFold
# 初始化随机森林分类器
clf = RandomForestClassifier(random_state=42)

# 定义StratifiedKFold用于交叉验证
cv = StratifiedKFold(n_splits=5)

# 递归特征消除和交叉验证
rfecv = RFECV(estimator=clf, step=1, cv=cv, scoring='accuracy')
rfecv.fit(X_train, y_train)

# 打印最佳特征数量
print(f"Optimal number of features: {rfecv.n_features_}")

# 获取交叉验证每一折的分数
cv_results = rfecv.cv_results_

# 取出5次交叉验证的单独分数
fold_scores = [cv_results[f'split{i}_test_score'] for i in range(5)]
mean_scores = cv_results['mean_test_score']  # 计算平均得分
# 输出选择的特征列
selected_features = X_train.columns[rfecv.support_]
print(f"Selected features: {list(selected_features)}")
df_selected = df[selected_features]
df_selected.head()


set(df.columns)-set(selected_features)


#9.2.2 递归特征消除与交叉验证结果可视化
plt.figure(figsize=(12, 8), dpi=120)
plt.title('Recursive Feature Elimination with Cross-Validation (RFCV)', 
          fontsize=16, fontweight='bold', pad=20)
plt.xlabel('Number of features selected', fontsize=14, labelpad=15)
plt.ylabel('Cross-validation score (accuracy)', fontsize=14, labelpad=15)
# 设置背景颜色
plt.gca().set_facecolor('#f7f7f7')
# 绘制每一条灰色线，表示5次交叉验证
for i in range(5):
    plt.plot(range(1, len(fold_scores[i]) + 1), fold_scores[i], marker='o', color='gray', linestyle='-', 
             linewidth=0.8, alpha=0.6)
# 绘制淡黑色线，表示平均交叉验证得分
plt.plot(range(1, len(mean_scores) + 1), mean_scores, marker='o', color='#696969', linestyle='-', 
         linewidth=3, label='Mean CV Accuracy')
# 绘制最佳特征数的垂直线
plt.axvline(x=rfecv.n_features_, color='#E76F51', linestyle='--', linewidth=2, label=f'Optimal = {rfecv.n_features_}')
plt.legend(fontsize=12, loc='best', frameon=True, shadow=True, facecolor='white', framealpha=0.9)
plt.grid(True, which='both', linestyle='--', linewidth=0.5, alpha=0.7)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)
plt.savefig('分类.pdf', format='pdf', bbox_inches='tight')
plt.show()



#9.3 模型构建
# 划分特征和目标变量
X = df_selected
y = df['NSP(label)_encoded']
# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, 
                                                    random_state=42, stratify=df['NSP(label)_encoded'])
import xgboost as xgb
from sklearn.model_selection import GridSearchCV

# 多分类XGBoost模型参数
params_xgb = {
    'learning_rate': 0.02,              # 学习率，控制每一步的步长
    'booster': 'gbtree',                # 使用梯度提升树
    'objective': 'multi:softmax',       # 损失函数，用于多分类的softmax
    'num_class': 3,                     # 分类类别数量，需根据具体的多分类任务调整
    'max_leaves': 127,                  # 每棵树的叶子节点数量
    'verbosity': 1,                     # 控制输出信息
    'seed': 42,                         # 随机种子
    'nthread': -1,                      # 使用所有可用的CPU核心
    'colsample_bytree': 0.6,            # 每棵树随机选择的特征比例
    'subsample': 0.7,                   # 每次迭代时随机选择的样本比例
    'eval_metric': 'mlogloss'           # 使用多分类对数损失作为评价指标
}

# 初始化XGBoost多分类模型
model_xgb = xgb.XGBClassifier(**params_xgb)

# 定义参数网格，用于网格搜索
param_grid = {
    'n_estimators': [100, 200, 300],    # 树的数量
    'max_depth': [3, 4, 5, 6],          # 树的深度
    'learning_rate': [0.01, 0.02, 0.05, 0.1]  # 学习率
}

# 使用GridSearchCV进行网格搜索和k折交叉验证
grid_search = GridSearchCV(
    estimator=model_xgb,
    param_grid=param_grid,
    scoring='neg_log_loss',  # 评价指标为负对数损失
    cv=5,                    # 5折交叉验证
    n_jobs=-1,               # 并行计算
    verbose=1                # 输出详细进度信息
)

# 训练模型
grid_search.fit(X_train, y_train)
# 使用最优参数训练模型
best_model = grid_search.best_estimator_

#9.4 XGBoost模型预测与分类性能评估
# 使用模型在测试集上进行预测
y_pred= best_model .predict(X_test)
from sklearn.metrics import classification_report
# 输出模型报告， 查看评价指标
print(classification_report(y_test, y_pred))


#9.5 XGBoost模型混淆矩阵可视化
from sklearn.metrics import confusion_matrix
import seaborn as sns
# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred)
# 绘制热力图
plt.figure(figsize=(10, 7), dpi = 120)
sns.heatmap(conf_matrix, annot=True, annot_kws={'size':15}, fmt='d', cmap='YlGnBu')
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('XGBoost Confusion matrix heat map', fontsize=15)
plt.savefig('XGBoost Confusion matrix heat map.pdf', format='pdf', bbox_inches='tight')
plt.show()


# XGBoost模型的ROC曲线和宏平均AUC计算
from sklearn import metrics
from sklearn.preprocessing import label_binarize

# 预测并计算概率
ytest_proba_xgb = best_model.predict_proba(X_test)

# 将y标签转换成one-hot形式
ytest_one_xgb = label_binarize(y_test, classes=[0, 1, 2])

# 宏平均法计算AUC
xgb_AUC = {}
xgb_FPR = {}
xgb_TPR = {}

for i in range(ytest_one_xgb.shape[1]):
    xgb_FPR[i], xgb_TPR[i], thresholds = metrics.roc_curve(ytest_one_xgb[:, i], ytest_proba_xgb[:, i])
    xgb_AUC[i] = metrics.auc(xgb_FPR[i], xgb_TPR[i])
print(xgb_AUC)

# 合并所有的FPR并排序去重
xgb_FPR_final = np.unique(np.concatenate([xgb_FPR[i] for i in range(ytest_one_xgb.shape[1])]))

# 计算宏平均TPR
xgb_TPR_all = np.zeros_like(xgb_FPR_final)
for i in range(ytest_one_xgb.shape[1]):
    xgb_TPR_all += np.interp(xgb_FPR_final, xgb_FPR[i], xgb_TPR[i])
xgb_TPR_final = xgb_TPR_all / ytest_one_xgb.shape[1]

# 计算最终的宏平均AUC
xgb_AUC_final = metrics.auc(xgb_FPR_final, xgb_TPR_final)
AUC_final_xgb = xgb_AUC_final  # 最终AUC

print(f"Macro Average AUC with XGBoost: {AUC_final_xgb}")

#9.6.2 宏平均ROC曲线绘制
plt.figure(figsize=(10, 10), dpi=120)
# 使用不同的颜色和线型绘制不同类别的ROC曲线
plt.plot(xgb_FPR[0], xgb_TPR[0], color='#1f77b4', linestyle='-', label='Class 0 ROC  AUC={:.4f}'.format(xgb_AUC[0]), lw=2)
plt.plot(xgb_FPR[1], xgb_TPR[1], color='#ff7f0e', linestyle='-', label='Class 1 ROC  AUC={:.4f}'.format(xgb_AUC[1]), lw=2)
plt.plot(xgb_FPR[2], xgb_TPR[2], color='#2ca02c', linestyle='-', label='Class 2 ROC  AUC={:.4f}'.format(xgb_AUC[2]), lw=2)
# 宏平均ROC曲线
plt.plot(xgb_FPR_final, xgb_TPR_final, color='#000000', linestyle='-', label='Macro Average ROC  AUC={:.4f}'.format(xgb_AUC_final), lw=3)
# 45度参考线
plt.plot([0, 1], [0, 1], color='gray', linestyle='--', lw=2, label='45 Degree Reference Line')
# 设置标签、标题和图例
plt.xlabel('False Positive Rate (FPR)', fontsize=15)
plt.ylabel('True Positive Rate (TPR)', fontsize=15)
plt.title('XGBoost Classification ROC Curves and AUC', fontsize=18)
plt.grid(linestyle='--', alpha=0.7)
plt.legend(loc='lower right', framealpha=0.9, fontsize=12)
plt.savefig('XGBoost_optimized.pdf', format='pdf', bbox_inches='tight')
plt.show()

#%%
#9.7  SHAP值计算整理
import shap
explainer = shap.TreeExplainer(best_model)
# 计算shap值为numpy.array数组
shap_values_numpy = explainer.shap_values(X)
# 计算shap值为Explanation格式
shap_values_Explanation = explainer(X)

#后补2025年7月23日
# 如果是列表，转换为 NumPy 数组
if isinstance(shap_values_numpy, list):
    shap_values_numpy = np.array(shap_values_numpy)



# 提取每个类别的 SHAP 值
shap_values_class_0 = shap_values_numpy[:, :, 0]
shap_values_class_1 = shap_values_numpy[:, :, 1]
shap_values_class_2 = shap_values_numpy[:, :, 2]
# 计算每个类别的特征贡献度
importance_class_0 = np.abs(shap_values_class_0).mean(axis=0)
importance_class_1 = np.abs(shap_values_class_1).mean(axis=0)
importance_class_2 = np.abs(shap_values_class_2).mean(axis=0)

print(f"importance_class_0:{importance_class_0}\
      \n\nimportance_class_1:{importance_class_1}\
      \n\nimportance_class_2:{importance_class_2}")


# 创建一个包含类别特征重要性的 DataFrame
importance_df = pd.DataFrame({
    'Class 0': importance_class_0,
    'Class 1': importance_class_1,
    'Class 2': importance_class_2,
     }, index=X_train.columns)

# 根据类别映射表将列名修改为英文描述
type_mapping = {
    0: 'Anomalous',  # 异常
    1: 'Normal',     # 正常
    2: 'Suspicious', # 可疑
}

# 修改列名
importance_df.columns = [type_mapping[int(col.split('Class ')[1])] for col in importance_df.columns]

# 添加一列用于存储行的和
importance_df['row_sum'] = importance_df.sum(axis=1)

# 按照行和对DataFrame进行排序
sorted_importance_df = importance_df.sort_values(by='row_sum', ascending=True)

# 删除用于排序的行和列
sorted_importance_df = sorted_importance_df.drop(columns=['row_sum'])

elements = sorted_importance_df.index

# 使用 Seaborn 的颜色调色板，设置为 Set2，以获得对比度更高的颜色
colors = sns.color_palette("Set2", n_colors=len(sorted_importance_df.columns))

# 创建图形和坐标轴对象，设置图形大小为12x6英寸，分辨率为1200 DPI
fig, ax = plt.subplots(figsize=(12, 6), dpi=1200)

# 初始化一个数组，用于记录每个条形图的底部位置，初始为0
bottom = np.zeros(len(elements))

# 遍历每个类别并绘制水平条形图
for i, column in enumerate(sorted_importance_df.columns):
    ax.barh(
        sorted_importance_df.index,     # y轴的特征名称
        sorted_importance_df[column],  # 当前类别的SHAP值
        left=bottom,                   # 设置条形图的起始位置
        color=colors[i],               # 使用调色板中的颜色
        label=column                   # 为图例添加类别名称
    )
    # 更新底部位置，以便下一个条形图能够正确堆叠
    bottom += sorted_importance_df[column]

# 设置x轴标签和标题
ax.set_xlabel('mean(SHAP value|)(average impact on model output magnitude)', fontsize=12)
ax.set_ylabel('Features', fontsize=12)
ax.set_title('Feature Importance by Class', fontsize=15)
# 设置y轴刻度和标签
ax.set_yticks(np.arange(len(elements)))
ax.set_yticklabels(elements, fontsize=10)
# 在条形图的末尾添加文本标签
for i, el in enumerate(elements):
    ax.text(bottom[i], i, ' ' + str(el), va='center', fontsize=9)
# 添加图例，并设置图例的字体大小和标题
ax.legend(title='Class', fontsize=10, title_fontsize=12)
# 禁用y轴的刻度和标签
ax.set_yticks([])  # 移除y轴刻度
ax.set_yticklabels([])  # 移除y轴刻度标签
ax.set_ylabel('')  # 移除y轴标签
# 移除顶部和右侧的边框，以获得更清晰的图形
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.savefig('average impact on model output magnitude.pdf', format='pdf', bbox_inches='tight')
plt.show()



plt.figure(figsize=(10, 5), dpi=120)
# 绘制第2个样本第0个类别的 SHAP 瀑布图，并设置 show=False 以避免直接显示
shap.plots.waterfall(shap_values_Explanation[:,:,0][1], show=False, max_display=13)
# 保存图像为 PDF 文件
plt.savefig("SHAP_Waterfall_Plot_Sample_1_0.pdf", format='pdf', bbox_inches='tight')
plt.tight_layout()
plt.show()


plt.figure(figsize=(10, 5), dpi=120)
# 绘制第2个样本第1个类别的 SHAP 瀑布图，并设置 show=False 以避免直接显示
shap.plots.waterfall(shap_values_Explanation[:,:,1][1], show=False, max_display=13)
# 保存图像为 PDF 文件
plt.savefig("SHAP_Waterfall_Plot_Sample_1_1.pdf", format='pdf', bbox_inches='tight')
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 5), dpi=120)
# 绘制第2个样本第2个类别的 SHAP 瀑布图，并设置 show=False 以避免直接显示
shap.plots.waterfall(shap_values_Explanation[:,:,2][1], show=False, max_display=13)
# 保存图像为 PDF 文件
plt.savefig("SHAP_Waterfall_Plot_Sample_1_2.pdf", format='pdf', bbox_inches='tight')
plt.tight_layout()
plt.show()







