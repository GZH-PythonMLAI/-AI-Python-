# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 21:17:10 2024

@author: yubg
"""
import numpy as np
from pandas import DataFrame
from pandas import Series
df = DataFrame({'age':Series([26,55,np.nan,85,85]),
                'name':Series(['Yubg','Cd','Jerry','John','John']),
                'birth':Series(['1976-09','1977-01','2005-05','2017-09','2017-09'])})
df

df.describe() 

from skimpy import skim
skim(df)

df.duplicated()
df[df.duplicated()]#显示重复行
df.duplicated('name')
df[~df.duplicated('name')]#先取反再取布尔值真，即删除nanme的重复行（保留第一次出现的）

df.drop_duplicates('age') #剔除age列中的重复行(不保留)

np.where(df.isnull()) 
df[df["age"].isnull()]

df.dropna()      # 删除有空值行  
df.fillna(0)     #用0填充空值


df.fillna('缺失')   #用字符串填充空值
df.fillna(df["age"].mean())  #用age列的均值 填充空值

df.ffill()    #bfill表示用前一个数据代替NaN
df.bfill()    #bfill表示用后一个数据代替NaN


#%%
import pandas as pd
d = {"gender":["male", "female", "male","female","female"],
      "color":["red", "green", "blue","green","yellow"],
      "age":[25, 30, 15, 32, 64] }
 
df = pd.DataFrame(d)
df

d = {"male": 1, "female": 0}
df["gender2"] = df["gender"].map(d)
df

df.age.map(lambda x:x+1)

df.age.replace(d)

df["mal_n"]=df.gender.apply(lambda x:1 if x=="male" else 0)
df




#按照年龄列进行分组cut()
#import numpy as np

# 将数组使用等距离的分位数进行分组
bins = [0, 18, 60, 100]
labels = ['青少年', '中年', '老年']
df["class_data"] = pd.cut(df.age, bins=bins, labels=labels, right=True)
print(df)

#df中的性别进行分类 groupby()
df.groupby("class_data")["age"].mean()
df.groupby("class_data")["gender2"].count()
df.groupby("gender2")["class_data"].count()

df["mal_n"] = df.mal_n.astype(int)

df.sort_values("mal_n", ascending=False, inplace=True)
    


























