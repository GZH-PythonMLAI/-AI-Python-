# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 21:00:32 2024

@author: yubg
"""

#%% #【也可以接着第七章不需运行这里的数据和xgboost】
import sys, shap, sklearn

print(f"python:{sys.version}")
print(f"scikit-learn:{sklearn.__version__}")
print(f"shap:{shap.__version__}")

#先加载第七章中的数据
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# 用黑体显示中文和负号
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

#导入本地数据
path = r"C:\Users\Administrator\OneDrive\出版\2025卫生出版社\i_nuc.xlsx"
df = pd.read_excel(path,sheet_name='heartdisease')
print(df.head())

# 划分特征和目标变量
X = df.drop(['target'], axis=1)
y = df['target']
# 划分训练集和测试集
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, 
                                                 random_state=42, 
                                                 stratify=df['target'])

import xgboost as xgb
from sklearn.model_selection import GridSearchCV

# XGBoost模型参数
params_xgb = {
    'learning_rate': 0.02,            
    'booster': 'gbtree',              
    'objective': 'binary:logistic', #二分类用binary:logistic，三分类用multi:softmax  
    'max_leaves': 127,                
    'verbosity': 1,                   
    'seed': 42,                       
    'nthread': -1,                    
    'colsample_bytree': 0.6,          
    'subsample': 0.7,                 
    'eval_metric': 'logloss'          
}


# 初始化XGBoost分类模型
model_xgb = xgb.XGBClassifier(**params_xgb)


# 定义参数网格，用于网格搜索
param_grid = {
    'n_estimators': [100, 200, 300, 400, 500],  # 树的数量
    'max_depth': [3, 4, 5, 6, 7],               # 树的深度
    'learning_rate': [0.01, 0.02, 0.05, 0.1],   # 学习率
}


# 使用GridSearchCV进行网格搜索和k折交叉验证
grid_search = GridSearchCV(
    estimator=model_xgb,
    param_grid=param_grid,
    scoring='neg_log_loss',  # 评价指标为负对数损失
    cv=5,                    # 5折交叉验证
    n_jobs=-1,               # 并行计算
    verbose=1                # 输出详细进度信息
)

# 训练模型
grid_search.fit(X_train, y_train)

# 输出最优参数
print("Best parameters found: ", grid_search.best_params_)
print("Best Log Loss score: ", -grid_search.best_score_)

# 使用最优参数训练模型
best_model_xgboost = grid_search.best_estimator_
# 对测试集进行预测
y_pred_3 = best_model_xgboost.predict(X_test)


"""
#随机森林
from sklearn.ensemble import RandomForestClassifier
  
# 创建随机森林分类器实例，并设置参数
rf_classifier = RandomForestClassifier(
      n_estimators=100,        
      criterion='gini',         
      max_depth=None,           
      min_samples_split=2,     
      min_samples_leaf=1,       
      min_weight_fraction_leaf=0.0, 
      random_state=42,          
      max_leaf_nodes=None,     
      min_impurity_decrease=0.0 
  )
  
# 训练模型
rf_classifier.fit(X_train, y_train)
使用 SHAP 库计算随机森林模型在测试集上的特征重要性（SHAP 值），并分别提取每个类别的 SHAP 值，以解释每个特征对不同类别预测结果的贡献。

"""

#%%

import shap 
explainer = shap.TreeExplainer(best_model_xgboost)# 构建 shap解释器
shap_values = explainer.shap_values(X_test)  # 计算测试集的shap值
labels = X_test.columns                      # 特征标签
 
plt.figure(dpi=150)   #以pdf方式保存可以dpi的至放大些，dpi=1200
shap.summary_plot(shap_values, X_test, feature_names=labels, plot_type="dot", show=False)
plt.savefig("摘要图.pdf", format='pdf', bbox_inches='tight')

#8.1.3
plt.figure(figsize=(15, 5),dpi=150)#以pdf方式保存可以dpi的至放大些，dpi=1200
shap.summary_plot(shap_values, X_test, plot_type="bar", show=False)
plt.title("shap Feature contributions")
plt.tight_layout()
plt.savefig("shap特征贡献图.pdf", format='pdf', bbox_inches='tight')
plt.show()

#8.1.4
shap.dependence_plot('trestbps', shap_values, X_test, interaction_index='chol', show=False)
plt.savefig("依赖图.pdf", format='pdf', bbox_inches='tight',dpi=150)


#8.1.5
# 绘制单个样本的SHAP解释（Force Plot）
sample_index = 7  # 选择一个样本索引进行解释
shap.force_plot(explainer.expected_value, shap_values[sample_index], X_test.iloc[sample_index], matplotlib=True, show=False)
plt.savefig("绘制指定样本力图.pdf", format='pdf', bbox_inches='tight')


#8.1.6热图（Heatmap）
# 绘制热图
# 创建 shap.Explanation 对象
shap_explanation = shap.Explanation(values=shap_values, 
                                    base_values=explainer.expected_value, 
                                    data=X_test, feature_names=X_test.columns)
# 绘制热图
shap.plots.heatmap(shap_explanation, show=False)
plt.savefig("热图.pdf", format='pdf', bbox_inches='tight')


#%%
# 8.2 保存模型
import sys, joblib
 
print(f"python:{sys.version}")
print(f"joblib:{joblib.__version__}")      

# 保存模型
joblib.dump(best_model_xgboost , 'best_model_xgboost.pkl')


#%%
#8.3模型调用
import joblib
# 加载训练好的随机森林模型
model = joblib.load('best_model_xgboost.pkl')


#先加载第七章中的数据
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

#导入本地数据
path = "d:/OneDrive/出版/2025卫生出版社/i_nuc.xlsx"
df = pd.read_excel(path,sheet_name='heartdisease')
print(df.head())

# 划分特征和目标变量
X = df.drop(['target'], axis=1)
y = df['target']
# 划分训练集和测试集
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, 
                                                 random_state=42, 
                                                 stratify=df['target'])

# 对加载的模型利用测试集进行预测
y_pred_3 = model.predict(X_test)
y_pred_3


#%%
#8.4模型APP部署
import sys, streamlit,joblib, shap, sklearn

print(f"python:{sys.version}")
print(f"streamlit:{streamlit.__version__}")
print(f"joblib:{joblib.__version__}")
print(f"scikit-learn:{sklearn.__version__}")


"""
要成功部署这个心脏病预测应用，你需要准备以下三个文件：
	Python 文件 (heart_disease_predictor.py)
	模型文件 (best_model_xgboost.pkl)
	依赖库文件 (requirements.txt)
Python 文件包含了 Streamlit 应用的所有代码，负责处理用户输入、加载模型、生成预测结果并显示 SHAP 可解释性图像。确保代码已经在本地正确运行，模型文件是训练好的随机森林模型的保存文件，依赖库文件列出了项目所需的所有库及其版本，它将被 Streamlit Cloud 用来安装部署应用时的所有依赖。
模型文件前面已经保存好了——best_model_xgboost.pkl，这里只需要准备heart_disease_predictor.py和requirements.txt两个文件。

"""

#1）准备部署所需的py文件。
import streamlit as st
import joblib
import numpy as np
import pandas as pd
import shap
import matplotlib.pyplot as plt

# 加载训练好的 XGBoost 模型
model = joblib.load('best_model_xgboost.pkl')

# 定义分类特征选项，如胸痛类型、静息心电图结果等，供用户选择
cp_options = {
    1: 'Typical angina (1)',      # 典型心绞痛
    2: 'Atypical angina (2)',     # 非典型心绞痛
    3: 'Non-anginal pain (3)',    # 非心绞痛
    4: 'Asymptomatic (4)'         # 无症状
}

restecg_options = {
    0: 'Normal (0)',              # 正常
    1: 'ST-T wave abnormality (1)', # ST-T波异常
    2: 'Left ventricular hypertrophy (2)' # 左心室肥大
}

slope_options = {
    1: 'Upsloping (1)',           # 上升型
    2: 'Flat (2)',                # 平坦型
    3: 'Downsloping (3)'          # 下降型
}

thal_options = {
    1: 'Normal (1)',              # 正常
    2: 'Fixed defect (2)',        # 固定缺陷
    3: 'Reversible defect (3)'    # 可逆缺陷
}

# 定义特征名称，用于 SHAP 值的解释
feature_names = [
    "Age", "Sex", "Chest Pain Type", "Resting Blood Pressure", "Serum Cholesterol",
    "Fasting Blood Sugar", "Resting ECG", "Max Heart Rate", "Exercise Induced Angina",
    "ST Depression", "Slope", "Number of Vessels", "Thal"
]

# Streamlit 用户界面标题
st.title("Heart Disease Predictor")

# 收集用户输入的特征信息
# 年龄：数值输入，范围从1到120，默认值为50
age = st.number_input("Age:", min_value=1, max_value=120, value=50)

# 性别：分类选择，0代表女性，1代表男性
sex = st.selectbox("Sex (0=Female, 1=Male):", options=[0, 1], format_func=lambda x: 'Female (0)' if x == 0 else 'Male (1)')

# 胸痛类型：分类选择，根据定义的 cp_options 显示具体选项
cp = st.selectbox("Chest pain type:", options=list(cp_options.keys()), format_func=lambda x: cp_options[x])

# 静息血压：数值输入，范围从50到200，默认值为120
trestbps = st.number_input("Resting blood pressure (trestbps):", min_value=50, max_value=200, value=120)

# 血清胆固醇：数值输入，范围从100到600，默认值为200
chol = st.number_input("Serum cholesterol in mg/dl (chol):", min_value=100, max_value=600, value=200)

# 空腹血糖：分类选择，0代表低于120 mg/dl，1代表高于120 mg/dl
fbs = st.selectbox("Fasting blood sugar > 120 mg/dl (fbs):", options=[0, 1], format_func=lambda x: 'False (0)' if x == 0 else 'True (1)')

# 静息心电图结果：分类选择
restecg = st.selectbox("Resting electrocardiographic results:", options=list(restecg_options.keys()), format_func=lambda x: restecg_options[x])

# 最大心率：数值输入，范围从50到250，默认值为150
thalach = st.number_input("Maximum heart rate achieved (thalach):", min_value=50, max_value=250, value=150)

# 运动诱发型心绞痛：分类选择，0代表没有，1代表有
exang = st.selectbox("Exercise induced angina (exang):", options=[0, 1], format_func=lambda x: 'No (0)' if x == 0 else 'Yes (1)')

# 运动引起的ST段压低：数值输入，范围从0.0到10.0，默认值为1.0
oldpeak = st.number_input("ST depression induced by exercise relative to rest (oldpeak):", min_value=0.0, max_value=10.0, value=1.0)

# 峰值运动ST段的斜率：分类选择
slope = st.selectbox("Slope of the peak exercise ST segment (slope):", options=list(slope_options.keys()), format_func=lambda x: slope_options[x])

# 荧光显示的主要血管数量：数值输入，范围从0到4，默认值为0
ca = st.number_input("Number of major vessels colored by fluoroscopy (ca):", min_value=0, max_value=4, value=0)

# 地中海贫血类型：分类选择
thal = st.selectbox("Thal (thal):", options=list(thal_options.keys()), format_func=lambda x: thal_options[x])

# 将所有输入的特征组合成一个数组用于模型预测
feature_values = [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
features = np.array([feature_values])

# 当用户点击“Predict”按钮时，进行预测
if st.button("Predict"):
    # 使用模型预测类别（0或1）和概率
    predicted_class = model.predict(features)[0]  # 预测类别
    predicted_proba = model.predict_proba(features)[0]  # 预测类别的概率

    # 显示预测结果
    st.write(f"**Predicted Class:** {predicted_class}")
    st.write(f"**Prediction Probabilities:** {predicted_proba}")

    # 根据预测结果生成建议
    probability = predicted_proba[predicted_class] * 100  # 将概率转换为百分比

    # 如果模型预测为类别1（心脏病风险），提供风险建议
    if predicted_class == 1:
        advice = (
            f"According to our model, you have a high risk of heart disease. "
            f"The model predicts that your probability of having heart disease is {probability:.1f}%. "
            "While this is just an estimate, it suggests that you may be at significant risk. "
            "I recommend that you consult a cardiologist as soon as possible for further evaluation and "
            "to ensure you receive an accurate diagnosis and necessary treatment."
        )
    # 如果模型预测为类别0（低风险），提供健康维护建议
    else:
        advice = (
            f"According to our model, you have a low risk of heart disease. "
            f"The model predicts that your probability of not having heart disease is {probability:.1f}%. "
            "However, maintaining a healthy lifestyle is still very important. "
            "I recommend regular check-ups to monitor your heart health, "
            "and to seek medical advice promptly if you experience any symptoms."
        )

    st.write(advice)  # 在界面上显示建议

    # 使用 SHAP 值计算并解释模型输出
    explainer = shap.TreeExplainer(model)  # 初始化 SHAP 解释器
    shap_values = explainer.shap_values(pd.DataFrame([feature_values], columns=feature_names))  # 计算输入特征的 SHAP 值

    # 根据预测类别显示 SHAP 力图
    shap.force_plot(explainer.expected_value, shap_values[0], pd.DataFrame([feature_values], columns=feature_names), matplotlib=True)
    
    # 将 SHAP 力图保存为图片文件
    plt.savefig("shap_force_plot.png", bbox_inches='tight', dpi=1200)



#2）准备requirements.txt文件。

"""
#以下是requirements.txt文件的内容。
streamlit==1.30.0
joblib==1.4.2
numpy==1.26.4
pandas==2.2.2
matplotlib==3.8.0
xgboost==2.0.3
scikit-learn==1.5.1
shap==0.45.1
"""






































