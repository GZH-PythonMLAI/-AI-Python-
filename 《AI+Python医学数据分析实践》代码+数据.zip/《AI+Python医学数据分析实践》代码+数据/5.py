# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 21:35:41 2024

@author: yubg
"""

import numpy as np
path = r"d:\OneDrive\出版\2025卫生出版社\pima-indians-diabetes.csv"
dataset = np.loadtxt(path, delimiter=",",skiprows=1)

X_new = dataset[-1,0:8]
Y_new = dataset[-1,8]

X = dataset[:-1,0:8]
Y = dataset[:-1,8]
print(len(X),len(Y))


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,Y,
                                               test_size=0.25,
                                               random_state=23)

from xgboost import XGBClassifier
model = XGBClassifier()
model.fit(X_train, y_train)

from sklearn.metrics import accuracy_score
y_pred = model.predict(X_test)
predictions = [round(value) for value in y_pred]
accuracy = accuracy_score(y_test, predictions)
print("Accuracy: %.2f%%" % (accuracy * 100.0))

model.score(X_test , y_test )  #测试精确度

print(X_test,"\n______________\n",X_new)

Y_pred = model.predict(np.array([X_new]))
print("预测结果为：%s"%Y_pred,"\n","真实结果为%s"%Y_new)


from matplotlib import pyplot
from xgboost import plot_importance
plot_importance(model)
pyplot.show()


#%%回归的案例

# 导入必要的库
import numpy as np  
from sklearn.model_selection import train_test_split  
from sklearn.linear_model import LinearRegression  
from sklearn.metrics import mean_squared_error  
  
# 生成模拟数据  
np.random.seed(0)  # 为了结果的可复现性  
# 假设有100个患者  
n_samples = 100  
# 特征：年龄（范围20-80岁），病情严重程度（范围1-10）  
X = np.random.rand(n_samples, 2) * [60, 9]  # 乘以系数以调整范围  
X[:, 0] += 20  # 调整为20-80岁  
X[:, 1] += 1    # 调整为1-10  
# 目标变量：住院时间（基于年龄和病情严重程度的线性组合，并添加一些噪声）  
y = 2 * X[:, 0] + 3 * X[:, 1] + np.random.randn(n_samples) * 10  # 假设平均住院时间与年龄和病情严重程度成线性关系，并有一定噪声  
  
# 划分训练集和测试集  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  
  
# 创建线性回归模型  
model = LinearRegression()  
  
# 训练模型  
model.fit(X_train, y_train)  
  
# 使用模型进行预测  
y_pred = model.predict(X_test)  
y_pred
  
# 计算并打印均方误差（MSE）  
mse = mean_squared_error(y_test, y_pred)  
print(f"Mean Squared Error: {mse:.2f}")  
  
# 假设有一个新患者的数据：年龄=50岁，病情严重程度=6  
new_patient = np.array([[50, 6]])  
predicted_stay = model.predict(new_patient)  
print(f"Predicted hospital stay for the new patient: {predicted_stay[0]:.2f} days")

#%% 聚类的案例

import pandas as pd  
from sklearn.cluster import KMeans  
from sklearn.preprocessing import StandardScaler  
import matplotlib.pyplot as plt  
  
# 假设数据集已经加载到DataFrame df中  
# 这里我们直接创建一个模拟的数据集作为示例  
data = {  
    '年龄': [45, 55, 65, 35, 40, 50, 60, 70, 30, 48],  
    '血压': [120, 140, 160, 110, 130, 150, 170, 180, 100, 125],  
    '血糖': [90, 120, 150, 80, 100, 110, 140, 160, 70, 95],  
    '胆固醇': [200, 220, 240, 180, 200, 210, 230, 250, 170, 190]  
}  
df = pd.DataFrame(data)
df  
  
# 数据标准化（因为K-Means对数据的尺度敏感）  
scaler = StandardScaler()  
X = scaler.fit_transform(df)  
  
# 使用K-Means算法进行聚类  
# 假设我们想要将患者分为3个群组  
kmeans = KMeans(n_clusters=3, random_state=42)  
kmeans.fit(X)  
  
# 将聚类标签添加到原始数据框中  
df['cluster'] = kmeans.labels_  
  
# 打印聚类结果  
print(df)  
  
# 可视化聚类结果（这里仅使用前两个主成分进行可视化）  
from sklearn.decomposition import PCA  
pca = PCA(n_components=2)  
X_pca = pca.fit_transform(X)  
  
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=kmeans.labels_, cmap='viridis')  
plt.xlabel('Principal Component 1')  
plt.ylabel('Principal Component 2')  
plt.title('Patient Clustering')  
plt.colorbar()  
plt.show()













