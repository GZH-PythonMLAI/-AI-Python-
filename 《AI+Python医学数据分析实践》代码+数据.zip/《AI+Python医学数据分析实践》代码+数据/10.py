# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 09:42:43 2024

@author: Administrator
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import seaborn as sns
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False

df = pd.read_excel('Parkinsons.xlsx')

# 分离特征和目标变量
X = df.drop(['total_UPDRS', 'motor_UPDRS'], axis=1)
y = df['total_UPDRS']

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, 
                                                    random_state=42)
df.head()


from sklearn.ensemble import RandomForestRegressor

# 创建随机森林回归器实例，并设置参数
rf_regressor = RandomForestRegressor(
    n_estimators=100,         
    criterion='squared_error', 
    max_depth=7,           
    min_samples_split=2,      
    min_samples_leaf=1,      
    min_weight_fraction_leaf=0.0, 
    random_state=42,          
    max_leaf_nodes=None,      
    min_impurity_decrease=0.0 
)

# 训练模型
rf_regressor.fit(X_train, y_train)


# 获取特征的重要性
feature_importances = rf_regressor.feature_importances_

# 将特征和其重要性一起排序
sorted_indices = np.argsort(feature_importances)[::-1]  # 逆序排列，重要性从高到低
sorted_features = X_train.columns[sorted_indices]
sorted_importances = feature_importances[sorted_indices]

# 打印排序后的特征及其重要性
for feature_name, importance in zip(sorted_features, sorted_importances):
    print(f"Feature: {feature_name}, Importance: {importance:.4f}")

# 绘制按重要性排序的特征贡献性柱状图
plt.figure(figsize=(10, 6), dpi=120)
plt.barh(sorted_features, sorted_importances, color='steelblue')
plt.xlabel('Importance', fontsize=14)
plt.ylabel('Features', fontsize=14)
plt.title('Sorted Feature Importance', fontsize=16)
plt.gca().invert_yaxis()
plt.savefig("Sorted Feature Importance.pdf", format='pdf',bbox_inches='tight')
# 显示图表
plt.show()


#10.4 特征选择
#10.4.1 蒙特卡洛模拟和交叉验证
from sklearn.model_selection import cross_val_score
# 创建新的 DataFrame，特征按贡献度排序
df_sorted_features = pd.DataFrame(df.drop(['total_UPDRS', 'motor_UPDRS'], axis=1)[sorted_features])

X = df_sorted_features
y = df['total_UPDRS']

best_params_rf = rf_regressor.get_params()

# 使用已训练的最佳参数
params_rf = {
    'n_estimators': best_params_rf['n_estimators'],  # 从已训练的随机森林模型获取
    'max_depth': best_params_rf['max_depth'],        # 从已训练的随机森林模型获取
    'min_samples_split': best_params_rf['min_samples_split'],  # 获取之前定义的最佳参数
    'min_samples_leaf': best_params_rf['min_samples_leaf'],    # 获取之前定义的最佳参数
    'criterion': best_params_rf['criterion'],        # 默认'squared_error'
    'random_state': best_params_rf['random_state'],  # 确保随机种子一致
}

# 输出最佳参数
print("Best Random Forest parameters: ", params_rf)

# 使用这些参数重新创建并训练模型
model_rf = RandomForestRegressor(**params_rf)

# 设置随机种子
np.random.seed(42)
n_features = X.shape[1]  # 假设你已经定义了特征矩阵 X
mc_no = 5  # 蒙特卡洛模拟的次数
cv_scores = np.zeros(n_features)  # 记录交叉验证分数

# 蒙特卡洛模拟
for j in range(mc_no):
    # 每次模拟都重新划分数据集
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8, random_state=j)
    
    # 逐步增加特征数量并进行交叉验证
    for i in range(1, n_features + 1):
        X_train_subset = X_train.iloc[:, :i]  # 选择前 i 个特征
        scores = cross_val_score(model_rf, X_train_subset, y_train, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
        cv_scores[i - 1] += scores.mean()

# 计算平均交叉验证分数 (由于是负的MSE，需要取反)
cv_scores /= mc_no
cv_scores = -cv_scores  # 取负值变成正的 MSE

# 绘图
plt.figure(figsize=(10, 6))
plt.plot(np.arange(1, n_features + 1), cv_scores, marker='o')
plt.xlabel('Number of features selected')
plt.ylabel('Cross validation score (negative MSE)')
plt.title('Feature Selection Impact on Model Performance (with Cross Validation)')
plt.grid(True)
plt.tight_layout()
plt.savefig("Feature Selection Impact on Model Performance (with Cross Validation).pdf", format='pdf',bbox_inches='tight')
plt.show()


#10.4.2 最佳特征选择
# 获取最佳特征数和最近的交叉验证得分
best_num_features = np.argmin(cv_scores) + 1  # 找到最小的MSE对应的特征数量
best_score = cv_scores[best_num_features - 1]  # 对应的最小MSE得分

# 获取最佳特征对应的列名
best_features = X_train.columns[:best_num_features]

# 打印结果
print(f"Best number of features: {best_num_features}")
print(f"Best cross-validation score (MSE): {best_score:.4f}")
print(f"Best features: {list(best_features)}")

# 根据最佳特征列名提取原始数据中的对应列
df_optimal_features = df[best_features]
df_optimal_features


#10.5 网格搜索和参数优化
from sklearn.model_selection import GridSearchCV
X = df_optimal_features
y = df['total_UPDRS']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, 
                                                    random_state=42)

# 随机森林模型参数
params_rf = {
    'n_estimators': 100,       
    'criterion': 'squared_error',  
    'random_state': 42,        
    'n_jobs': -1,  
    'max_depth': 7,  
}

# 创建随机森林回归模型
model_rf = RandomForestRegressor(**params_rf)

# 定义参数网格，用于网格搜索
param_grid_rf = {
    'n_estimators': [100, 200, 300],           
    'min_samples_split': [2, 5],           
    'min_samples_leaf': [1, 2]            
}

# 网格搜索
grid_search_rf = GridSearchCV(
    estimator=model_rf,
    param_grid=param_grid_rf,
    scoring='neg_root_mean_squared_error',  
    cv=5,  
    n_jobs=-1,  
)

# 训练模型
grid_search_rf.fit(X_train, y_train)

# 获取最优模型
best_rf_model = grid_search_rf.best_estimator_


#10.6 模型评价
import sklearn.metrics as metrics

# 预测
y_pred_train =best_rf_model.predict(X_train)
y_pred_test = best_rf_model.predict(X_test)

y_pred_train_list = y_pred_train.tolist()
y_pred_test_list = y_pred_test.tolist()

# 计算训练集的指标
mse_train = metrics.mean_squared_error(y_train, y_pred_train_list)
rmse_train = np.sqrt(mse_train)
mae_train = metrics.mean_absolute_error(y_train, y_pred_train_list)
r2_train = metrics.r2_score(y_train, y_pred_train_list)

# 计算测试集的指标
mse_test = metrics.mean_squared_error(y_test, y_pred_test_list)
rmse_test = np.sqrt(mse_test)
mae_test = metrics.mean_absolute_error(y_test, y_pred_test_list)
r2_test = metrics.r2_score(y_test, y_pred_test_list)

# 将指标放入列表
metrics_labels = ['MSE', 'RMSE', 'MAE', 'R-squared']
train_metrics = [mse_train, rmse_train, mae_train, r2_train]
test_metrics = [mse_test, rmse_test, mae_test, r2_test]

# 创建柱状图
x = np.arange(len(metrics_labels))  # 横坐标位置
width = 0.35  # 柱子的宽度

fig, ax = plt.subplots()

# 训练集和测试集的柱子
bars1 = ax.bar(x - width/2, train_metrics, width, label='Train')
bars2 = ax.bar(x + width/2, test_metrics, width, label='Test')

# 添加标签和标题
ax.set_ylabel('Scores')
ax.set_title('Comparison of Train and Test Set Metrics')
ax.set_xticks(x)
ax.set_xticklabels(metrics_labels)
ax.legend()

# 在每个柱子上显示数值
def autolabel(bars):
    """在每个柱子上显示数值."""
    for bar in bars:
        height = bar.get_height()
        ax.annotate('{}'.format(round(height, 3)),
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),  # 3 点垂直偏移
                    textcoords="offset points",
                    ha='center', va='bottom')

autolabel(bars1)
autolabel(bars2)

fig.tight_layout()
plt.savefig("Comparison of Train and Test Set Metrics.pdf", format='pdf',bbox_inches='tight')
plt.show()


#10.7 预测结果可视化
#自定义函数：在每个柱子上显示数值
autolabel(bars1)  
autolabel(bars2)

# 创建一个包含训练集和测试集真实值与预测值的数据框
data_train = pd.DataFrame({
    'True': y_train,
    'Predicted': y_pred_train,
    'Data Set': 'Train'
})

data_test = pd.DataFrame({
    'True': y_test,
    'Predicted': y_pred_test,
    'Data Set': 'Test'
})

data = pd.concat([data_train, data_test])

# 自定义调色板
palette = {'Train': '#b4d4e1', 'Test': '#f4ba8a'}

# 创建 JointGrid 对象
plt.figure(figsize=(8, 6), dpi=1200)
g = sns.JointGrid(data=data, x="True", y="Predicted", hue="Data Set", height=10, palette=palette)

# 绘制中心的散点图
g.plot_joint(sns.scatterplot, alpha=0.5)
# 添加训练集的回归线
sns.regplot(data=data_train, x="True", y="Predicted", scatter=False, ax=g.ax_joint, color='#b4d4e1', label='Train Regression Line')
# 添加测试集的回归线
sns.regplot(data=data_test, x="True", y="Predicted", scatter=False, ax=g.ax_joint, color='#f4ba8a', label='Test Regression Line')
# 添加边缘的柱状图
g.plot_marginals(sns.histplot, kde=False, element='bars', multiple='stack', alpha=0.5)

# 添加拟合优度文本在右下角
ax = g.ax_joint
ax.text(0.95, 0.1, f'Train $R^2$ = {r2_train:.3f}', transform=ax.transAxes, fontsize=12,
        verticalalignment='bottom', horizontalalignment='right', bbox=dict(boxstyle="round,pad=0.3", edgecolor="black", facecolor="white"))
ax.text(0.95, 0.05, f'Test $R^2$ = {r2_test:.3f}', transform=ax.transAxes, fontsize=12,
        verticalalignment='bottom', horizontalalignment='right', bbox=dict(boxstyle="round,pad=0.3", edgecolor="black", facecolor="white"))
# 在左上角添加模型名称文本
ax.text(0.75, 0.99, 'Model = RF', transform=ax.transAxes, fontsize=12,
        verticalalignment='top', horizontalalignment='left', bbox=dict(boxstyle="round,pad=0.3", edgecolor="black", facecolor="white"))

# 添加中心线
ax.plot([data['True'].min(), data['True'].max()], [data['True'].min(), data['True'].max()], c="black", alpha=0.5, linestyle='--', label='x=y')
ax.legend()
plt.savefig("TrueFalse.pdf", format='pdf', bbox_inches='tight')
plt.show()

























