# -*- coding: utf-8 -*-
"""
Created on Sun Sep  8 19:52:53 2024

@author: yubg
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# 用黑体显示中文和负号
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

#导入本地数据
path = "d:/OneDrive/出版/2025卫生出版社/i_nuc.xlsx"
df = pd.read_excel(path,sheet_name='heartdisease')
print(df.head())

# 划分特征和目标变量
X = df.drop(['target'], axis=1)
y = df['target']
# 划分训练集和测试集
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2, 
                                                 random_state=42, 
                                                 stratify=df['target'])


# 导入所需的库  
from sklearn.tree import DecisionTreeClassifier  # 从sklearn.tree模块导入DecisionTreeClassifier类，用于创建决策树分类器  
  
# 创建决策树分类器实例，并设置参数  
dt_classifier = DecisionTreeClassifier(  
    criterion='gini',        # 使用基尼系数作为分裂质量的衡量标准  
    splitter='best',         # 选择最佳分裂（'best'）或随机分裂（'random'）  
    max_depth=None,          # 树的最大深度，None表示节点展开直到所有叶子都是纯净的或者包含少于min_samples_split个样本  
    min_samples_split=2,     # 分裂内部节点所需的最小样本数  
    min_samples_leaf=1,      # 在叶节点处需要的最小样本数  
    min_weight_fraction_leaf=0.0, # 在所有叶子节点中的最小加权分数，用于处理加权样本  
    max_features=None,       # 寻找最佳分裂时要考虑的特征数量，None表示考虑所有特征  
    random_state=42,         # 控制构建树时的随机性，确保结果的可重复性  
    max_leaf_nodes=None,     # 最大叶子节点数，通过max_leaf_nodes来“预剪枝”  
    min_impurity_decrease=0.0 # 如果节点的分裂导致不纯度的减少大于或等于此值，则节点将被分裂  
)  
  
# 训练模型  
dt_classifier.fit(X_train, y_train)  # 使用训练数据（X_train为特征，y_train为目标变量）来训练决策树分类器  
  
# 对测试集进行预测  
y_pred_1 = dt_classifier.predict(X_test)  # 使用训练好的决策树分类器对测试集（X_test）进行预测，得到预测结果y_pred_1

print(y_pred_1)

from sklearn.metrics import classification_report
# 输出模型报告， 查看评价指标
print(classification_report(y_test, y_pred_1))



#7.2 决策树模型混淆矩阵热力图
from sklearn.metrics import confusion_matrix
import seaborn as sns
# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred_1)

# 绘制热力图
plt.figure(figsize=(5, 3), dpi=120)
sns.heatmap(conf_matrix, annot=True, annot_kws={'size':15}, fmt='d', cmap='YlGnBu', cbar_kws={'shrink': 0.75})
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('决策树混淆矩阵热力图', fontsize=15)
plt.savefig("决策树混淆矩阵热力图.pdf", format='pdf', bbox_inches='tight')
plt.show()


# 决策树模型ROC曲线
from sklearn.metrics import roc_curve, auc

# 预测概率
y_score_1 = dt_classifier.predict_proba(X_test)[:, 1]

# 计算ROC曲线
fpr_logistic_1, tpr_logistic_1, _ = roc_curve(y_test, y_score_1)
roc_auc_logistic_1 = auc(fpr_logistic_1, tpr_logistic_1)

# 绘制ROC曲线
plt.figure()
plt.plot(fpr_logistic_1, tpr_logistic_1, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc_logistic_1)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig("决策树ROC曲线图.pdf", format='pdf', bbox_inches='tight')
plt.show()

#%%
#7.3.2 随机森林模型
from sklearn.ensemble import RandomForestClassifier

# 创建随机森林分类器实例，并设置参数
rf_classifier = RandomForestClassifier(
    n_estimators=100,        
    criterion='gini',         
    max_depth=None,           
    min_samples_split=2,     
    min_samples_leaf=1,       
    min_weight_fraction_leaf=0.0, 
    random_state=42,          
    max_leaf_nodes=None,     
    min_impurity_decrease=0.0 
)

# 训练模型
rf_classifier.fit(X_train, y_train)

# 对测试集进行预测
y_pred_2 = rf_classifier.predict(X_test)

# 输出模型报告， 查看评价指标
print(classification_report(y_test, y_pred_2))


# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred_2)

# 绘制热力图，结果如图7-3所示
plt.figure(figsize=(10, 7), dpi=100)
sns.heatmap(conf_matrix, annot=True, annot_kws={'size':15}, fmt='d', cmap='YlGnBu', cbar_kws={'shrink': 0.75})
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('随机森林混淆矩阵热力图', fontsize=15)
plt.savefig("随机森林混淆矩阵热力图.pdf", format='pdf', bbox_inches='tight')
plt.show()


y_score_2 = rf_classifier.predict_proba(X_test)[:, 1]

# 计算ROC曲线
fpr_logistic_2, tpr_logistic_2, _ = roc_curve(y_test, y_score_2)
roc_auc_logistic_2 = auc(fpr_logistic_2, tpr_logistic_2)

# 绘制ROC曲线，结果如图-3所示
plt.figure()
plt.plot(fpr_logistic_2, tpr_logistic_2, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc_logistic_2)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig("随机森林ROC曲线图.pdf", format='pdf', bbox_inches='tight')
plt.show()


#7.3.3 XGBoost模型
import xgboost as xgb
from sklearn.model_selection import GridSearchCV

# XGBoost模型参数
params_xgb = {
    'learning_rate': 0.02,            
    'booster': 'gbtree',              
    'objective': 'binary:logistic', #二分类用binary:logistic，三分类用multi:softmax  
    'max_leaves': 127,                
    'verbosity': 1,                   
    'seed': 42,                       
    'nthread': -1,                    
    'colsample_bytree': 0.6,          
    'subsample': 0.7,                 
    'eval_metric': 'logloss'          
}


# 初始化XGBoost分类模型
model_xgb = xgb.XGBClassifier(**params_xgb)


# 定义参数网格，用于网格搜索
param_grid = {
    'n_estimators': [100, 200, 300, 400, 500],  # 树的数量
    'max_depth': [3, 4, 5, 6, 7],               # 树的深度
    'learning_rate': [0.01, 0.02, 0.05, 0.1],   # 学习率
}


# 使用GridSearchCV进行网格搜索和k折交叉验证
grid_search = GridSearchCV(
    estimator=model_xgb,
    param_grid=param_grid,
    scoring='neg_log_loss',  # 评价指标为负对数损失
    cv=5,                    # 5折交叉验证
    n_jobs=-1,               # 并行计算
    verbose=1                # 输出详细进度信息
)

# 训练模型
grid_search.fit(X_train, y_train)

# 输出最优参数
print("Best parameters found: ", grid_search.best_params_)
print("Best Log Loss score: ", -grid_search.best_score_)

# 使用最优参数训练模型
best_model_xgboost = grid_search.best_estimator_
# 对测试集进行预测
y_pred_3 = best_model_xgboost.predict(X_test)


# 输出模型报告， 查看评价指标
print(classification_report(y_test, y_pred_3))


# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred_3)

# 绘制热力图
plt.figure(figsize=(10, 7), dpi=1200)
sns.heatmap(conf_matrix, annot=True, annot_kws={'size':15}, fmt='d', cmap='YlGnBu', cbar_kws={'shrink': 0.75})
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('XGBoost混淆矩阵热力图', fontsize=15)
plt.savefig("XGBoost混淆矩阵热力图.pdf", format='pdf', bbox_inches='tight')
plt.show()


# 预测概率
y_score_3 = best_model_xgboost.predict_proba(X_test)[:, 1]

# 计算ROC曲线
fpr_logistic_3, tpr_logistic_3, _ = roc_curve(y_test, y_score_3)
roc_auc_logistic_3 = auc(fpr_logistic_3, tpr_logistic_3)

# 绘制ROC曲线
plt.figure()
plt.plot(fpr_logistic_3, tpr_logistic_3, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc_logistic_3)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig("XGBoost ROC曲线图.pdf", format='pdf', bbox_inches='tight')
plt.show()

#%%
#7.3.4 CatBoost模型

# 导入所需的库
from catboost import CatBoostClassifier

# CatBoost模型参数
params_catboost = {
    'learning_rate': 0.02,            
    'depth': 6,                       
    'loss_function': 'Logloss',       
    'verbose': 100,                   
    'random_seed': 42,                
    'thread_count': -1,               
    'subsample': 0.7,                 
    'l2_leaf_reg': 3.0                
}

# 初始化CatBoost分类模型
model_catboost = CatBoostClassifier(**params_catboost)

# 定义参数网格，用于网格搜索
param_grid_catboost = {
    'iterations': [100, 200, 300, 400, 500],  # 迭代次数，相当于树的数量
    'depth': [3, 4, 5, 6, 7],                 # 树的深度
    'learning_rate': [0.01, 0.02, 0.05, 0.1], # 学习率
}

# 使用GridSearchCV进行网格搜索和k折交叉验证
grid_search_catboost = GridSearchCV(
    estimator=model_catboost,
    param_grid=param_grid_catboost,
    scoring='neg_log_loss',  # 评价指标为负对数损失
    cv=5,                    # 5折交叉验证
    n_jobs=-1,               # 并行计算
    verbose=0                # 输出详细进度信息
)

# 训练模型
grid_search_catboost.fit(X_train, y_train)

# 输出最优参数
print("Best parameters found: ", grid_search_catboost.best_params_)
print("Best Log Loss score: ", -grid_search_catboost.best_score_)

# 使用最优参数训练模型
best_model_catboost = grid_search_catboost.best_estimator_
# 对测试集进行预测
y_pred_4 = best_model_catboost.predict(X_test)

# 输出模型报告， 查看评价指标
print(classification_report(y_test, y_pred_4))


# 输出混淆矩阵
conf_matrix = confusion_matrix(y_test, y_pred_4)

# 绘制热力图
plt.figure(figsize=(10, 7), dpi=500)
sns.heatmap(conf_matrix, annot=True, annot_kws={'size':15}, fmt='d', cmap='YlGnBu', cbar_kws={'shrink': 0.75})
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.title('Catboost混淆矩阵热力图', fontsize=15)
plt.savefig("Catboost混淆矩阵热力图.pdf", format='pdf', bbox_inches='tight')
plt.show()



# 预测概率
y_score_4 = best_model_catboost.predict_proba(X_test)[:, 1]

# 计算ROC曲线
fpr_logistic_4, tpr_logistic_4, _ = roc_curve(y_test, y_score_4)
roc_auc_logistic_4 = auc(fpr_logistic_4, tpr_logistic_4)

# 绘制ROC曲线
plt.figure()
plt.plot(fpr_logistic_4, tpr_logistic_4, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc_logistic_4)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig("Catboost ROC曲线图.pdf", format='pdf', bbox_inches='tight')
plt.show()


# 在同一张画布下绘制ROC曲线
plt.figure(figsize=(10, 8))  
plt.plot(fpr_logistic_1, tpr_logistic_1, color='blue', lw=2, linestyle='-',         label='DT ROC curve (area = %0.2f)' % roc_auc_logistic_1)
plt.plot(fpr_logistic_2, tpr_logistic_2, color='green', lw=2, linestyle='-', label='RF ROC curve (area = %0.2f)' % roc_auc_logistic_2)
plt.plot(fpr_logistic_3, tpr_logistic_3, color='red', lw=2, linestyle='-', label='XGBoost ROC curve (area = %0.2f)' % roc_auc_logistic_3)
plt.plot(fpr_logistic_4, tpr_logistic_4, color='purple', lw=2, linestyle='-', label='Catboost ROC curve (area = %0.2f)' % roc_auc_logistic_4)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('Receiver Operating Characteristic', fontsize=16)
plt.grid(alpha=0.3)
plt.legend(loc="lower right", fontsize=12)
plt.savefig("ROC曲线图.pdf", format='pdf', bbox_inches='tight')
plt.show()







