# -*- coding: utf-8 -*-
"""
Created on Wed Mar  5 23:02:44 2025

@author: yubg
"""





#%%
#2.1.2 条件筛选
import numpy as np
np.random.seed(2025)
w = np.random.randint(33,56,(3,5))   #创建随机数据
w

w < 35           #获得体重低于35的布尔数组
w[w<35]            #筛选出体重低于35的数组元素

cond = (w>40) & (w<50)   #获得体重在40~50的布尔数组
cond

w[cond]

idx = np.where((w>40)&(w<50))  #获得体重在40~50之间元素的索引
idx

w[idx]

np.extract(((w>40) & (w<50))| (w<35), w)


#%%
#2.2.1 Series的创建与访问
import numpy as np
import pandas as pd
#直接给定列表创建序列series1
series1 = pd.Series([45,12,56,24,35],['a','b','c','d','e'])   
series1

lis = [60.5,1620,447,2890,345,1800,1970,37.8]
elem = ['Ca','K','Fe','Cl','P','S','Na','Mg']
bld = pd.Series(lis,elem)   #通过列表list1创建序列blood
bld

narr1 = np.array(['father','mother','brother','sister','son','daughter'])
cn = pd.Series(narr1)   #通过数组narr1创建序列callname
cn

dict1 = {'orange':4.0,'pear':3.5,'apple':6,'grape':12.5}
#通过字典dict1创建序列price，索引为字典的键
price = pd.Series(dict1)   
price


import pandas as pd
L_1 = ['aa','bb','cc','dd','ee']
s1 = pd.Series(L_1)   
s1

s1[3]

s2 = pd.Series(L_1,index=list("abcde"))   
s2

s2["d"]

s1[:3]

s1[::2]

s1[::-1]

s1                  #查看序列s1

s1[2] = "c2"       #修改序列索引号为2的元素值为c2
s1            #再次查看s1，索引号为2的位置值元素改为了c2

s1[5] = "ff"     #当索引号不存在时，则为增加该元素

s1            #再次查看，发现增加了原索引号不存在的元素ff

s2 = pd.Series(L_1,index=list("abcde"))   #创建s2序列
s2

pd.concat([s1,s2])

import pandas as pd
data = {'A': 10, 'B': 20, 'C': 30}
s = pd.Series(data)
s

s.index

s.index = range(len(s))     #修改标签为默认数字标签
s

s1_s2 = pd.concat([s1,s2])
s1_s2.index = range(len(s1_s2))
s1_s2


dic = {'A': 1, 'B': 5, 'C': 3}
s = pd.Series(dic)             #创建序列
s

s.sort_index(ascending=False)  #按照标签/索引降序排列

s.sort_values(ascending=True) #按照序列值升序排列

s              #原序列并未被改变

s.drop("B")    #删除标签为B的元素
s            #原序列不改变

del s["B"]   #删除标签为B的元素
s            #原序列改变了 


import pandas as pd
dic = {'A': [1,2,3], 'B': list("abc"),"C":[5,1,3]}
df = pd.DataFrame(dic)      #按字典创建数据框
df


import numpy as np
arr = np.random.randint(0,10,(3,4))
df1 = pd.DataFrame(arr,columns=list("ABCD")) #由数组创建数据框
df1   

len(df)
df.columns          #提取列名
df.index            #提取行索引
df.index.tolist()   #转化为列表
df.shape

import numpy as np
import pandas as pd
arr = np.random.randint(0,10,(3,4))
df1 = pd.DataFrame(arr,columns=list("ABCD"))
df1
df1.iloc[:2,1:3]
df1.loc[1:2,"B"]
df1.loc[:2,"A":"C"]  #提取A到C列
df1.loc[:2,["A","C"]]    #按给定的列名（做成了列表）提取
df1.iloc[1]    #提取行索引为1的行
df1.loc[2]      #提取行标签为2的行

df2 = pd.DataFrame(arr,columns=list("ABCD"),index=list("abc"))
df2
df2.loc["c"]     #按编号提取c行
df2.iloc[1]   #按索引号提取b行
df2["B"]     #提取B列
df2.B
df2.head(2)      #查看df2的前2行数据，默认是5行
df2.tail(2)     #查看df2的末尾2行数据，默认是5行


import numpy as np
import pandas as pd
np.random.seed(20231005)       #随机种子，保证每次取随机数相同
arr = np.random.randint(0,50,(4,3))  #产生随机的数组
df3 = pd.DataFrame(arr,columns=list("ABC"),index=list("abcd"))
df3
df3.B.between(10,40) #选出B列位于10和40之间的数据，返回逻辑值
df3[df3.B.between(10,40)] #筛选出符合条件的数据行
df3[~df3.B.between(10,40)] #筛选出介于10到40之间以外的数据行
df3[~(df3.C>40)]   #选出C列中>40的数据并取反
df3["D"] = range(len(df3["B"]))# len(df3["B"])表示B列的元素个数
w = [1,2,3,4,5]
df3.loc[4] = w              #在原数据框上增加行
df3
d ={'A':11, 'D2':12, 'B':13, 'C':14, 'D':15}
d0 = pd.DataFrame(d,index=[0])
pd.concat([df3,d0],ignore_index=True)  #生成一个新的数据框

df3.drop(4,inplace=True)   #在数据框上直接删除行标签为4的行
df3
df3.drop("D2",axis=1)   #删除列D2并生成新的数据框
df3.drop(["D2","D"],axis=1,inplace=True)#在原数据框上删除D2和D列
df3.loc["c","B"] = 0   #将df3中c行B列交叉位置上数据修改为0
df3                    #原数据框被修改
df3["A"] = [0,1,2,3]   #修改df3的A列
df3
df3.loc["d"] = [2,3,0]   #修改df3的d行 
df3
df3.replace(0,99,inplace=True)  #将df3中的所有0修改为99
df3
df3.replace({1:88,2:77}) #将df3中所有的1换成88，2换成77
df3
df3.sort_index(axis=0,ascending=False) #按行索引降序排
df3.sort_values(by="B")  #按照B列升序排
df3.reset_index()   #直接换成默认的索引，原索引保存为一列
df3.reset_index(drop=True,inplace=False) #启用了drop参数为True
df3.set_index("B")  #将原数据框中的B列设置为新的索引
df3.index = [1,2,3,4]
df3

#%%
#2.3 读存数据
import pandas as pd
path_csv = r"d:\OneDrive\i_nuc.csv"
df = pd.read_csv(path_csv)
df.head()

df = pd.read_csv(path_csv,index_col=0)
df.tail()

path_txt = r"d:\OneDrive\i_nuc.txt"
df = pd.read_csv(path_txt,sep="\t",index_col=0,encoding="gbk")
df.head()

pd.read_table(path_txt,index_col=0,encoding="gbk")


path_xlsx = r"d:\OneDrive\i_nuc.xlsx"
df = pd.read_excel(path_xlsx,sheet_name="Sheet4")
df.head()

df.to_excel("c:/Users/yubg/Desktop/1.xlsx")  #保存在桌面上
df.to_csv("c:/Users/yubg/Desktop/2.csv")
df.to_csv("c:/Users/yubg/Desktop/3.txt")
df.to_csv("c:/Users/yubg/Desktop/22.csv",encoding="gbk")


from joblib import dump, load
import numpy as np
# 创建一个大的numpy数组
big_array = np.random.rand(10000, 10000)
# 保存数组
dump(big_array, 'big_array.joblib')


from joblib import dump, load
loaded_array = load('big_array.joblib')


import pandas as pd
path_xlsx = r"d:\OneDrive\i_nuc.xlsx"
df = pd.read_excel(path_xlsx,sheet_name="Sheet3")
df.head()


df.班级.dtype      #查看班级列数据类型
bj = df.班级.astype("str").map(lambda x:x[-2:])
bj
df.班级.apply(lambda x:str(x)[-2:])
bj.unique()        #找出不同班级
bj.nunique()       #找出不同班级，给出不同班级数
bj.value_counts()  #找出不同班级号出现的次数
df.isnull().tail(6)
df[df.isnull().any(axis=1)]
data = pd.DataFrame(data={"A":[1,2,3],"B":[0,0,0],"C":[0,2,0]})
data
data.any()      # B列全部为0
df.rename(columns={"班级":"班级名"}).head()

#%%
import pandas as pd
dic = {'A': [1,2,3], 'B': list("abc"),"C":[5,1,3]}
df = pd.DataFrame(dic)      #按字典创建数据框
df

import numpy as np
arr = np.random.randint(0,10,(3,4))
df1 = pd.DataFrame(arr,columns=list("ABCD")) #由数组创建数据框
df1

len(df)
df.columns          #提取列名
df.index            #提取行索引
df.index.tolist()   #转化为列表
df.shape

import numpy as np
import pandas as pd
arr = np.random.randint(0,10,(3,4))
df1 = pd.DataFrame(arr,columns=list("ABCD"))
df1
df1.iloc[:2,1:3]
df1.loc[1:2,"B"]
df1.loc[:2,"A":"C"]  #提取A到C列
df1.loc[:2,["A","C"]]    #按给定的列名（做成了列表）提取
df1.iloc[1]    #提取行索引为1的行
df1.loc[2]      #提取行标签为2的行
df2 = pd.DataFrame(arr,columns=list("ABCD"),index=list("abc"))
df2
df2.loc["c"]     #按编号提取c行
df2.iloc[1]   #按索引号提取b行
df2["B"]     #提取B列
df2.B
df2.head(2)      #查看df2的前2行数据，默认是5行
df2.tail(2)     #查看df2的末尾2行数据，默认是5行


#2.2.4 条件筛选 
import numpy as np
import pandas as pd
np.random.seed(20231005)       #随机种子，保证每次取随机数相同
arr = np.random.randint(0,50,(4,3))  #产生随机的数组
df3 = pd.DataFrame(arr,columns=list("ABC"),index=list("abcd"))
df3
df3.B.between(10,40) #选出B列位于10和40之间的数据，返回逻辑值

#
df3[df3.B.between(10,40)] #筛选出符合条件的数据行
df3[~df3.B.between(10,40)] #筛选出介于10到40之间以外的数据行
df3[~(df3.C>40)]   #选出C列中>40的数据并取反
df3["D"] = range(len(df3["B"]))# len(df3["B"])表示B列的元素个数
df3
w = [1,2,3,4,5]
df3.loc[4] = w              #在原数据框上增加行

d ={'A':11, 'D2':12, 'B':13, 'C':14, 'D':15}
d0 = pd.DataFrame(d,index=[0])  #给出了索引值index=[0]
pd.concat([df3,d0],ignore_index=True)  #生成一个新的数据框
df3.drop(4,inplace=True)   #在数据框上直接删除行标签为4的行
df3

df3.drop("D2",axis=1)   #删除列D2并生成新的数据框
df3.drop(["D2","D"],axis=1,inplace=True)#在原数据框上删除D2和D列
df3
df3.loc["c","B"] = 0   #将df3中c行B列交叉位置上数据修改为0

df3                    #原数据框被修改
df3["A"] = [0,1,2,3]   #修改df3的A列
df3
df3.loc["d"] = [2,3,0]   #修改df3的d行 
df3
df3.replace(0,99,inplace=True)  #将df3中的所有0修改为99
df3
df3.replace({1:88,2:77}) #将df3中所有的1换成88，2换成77

#2.2.6 排序 
df3.sort_index(axis=0,ascending=False) #按行索引降序排
df3.sort_values(by="B")  #按照B列升序排


#索引重置 
df3.reset_index()   #直接换成默认的索引，原索引保存为一列
df3.reset_index(drop=True,inplace=False) #启用了drop参数为True

df3.set_index("B")  #将原数据框中的B列设置为新的索引
df3.index = [1,2,3,4]
df3

#2.3 读存数据
import pandas as pd
path_csv = r"d:\OneDrive\i_nuc.csv"
df = pd.read_csv(path_csv)
df.head()

df = pd.read_csv(path_csv,index_col=0)
df.tail()

path_txt = r"d:\OneDrive\i_nuc.txt"
df = pd.read_csv(path_txt,sep="\t",index_col=0,encoding="gbk")
df.head()

pd.read_table(path_txt,index_col=0,encoding="gbk")

path_xlsx = r"d:\OneDrive\i_nuc.xlsx"
df = pd.read_excel(path_xlsx,sheet_name="Sheet4")
df.head()

df.to_excel("c:/Users/yubg/Desktop/1.xlsx")  #保存在桌面上
df.to_csv("c:/Users/yubg/Desktop/2.csv")
df.to_csv("c:/Users/yubg/Desktop/3.txt")
df.to_csv("c:/Users/yubg/Desktop/22.csv",encoding="gbk")


#3.保存变量
from joblib import dump, load
import numpy as np

# 创建一个大的numpy数组
big_array = np.random.rand(10000, 10000)

# 保存数组
dump(big_array, 'big_array.joblib')

#当重新开机需要打开big_array数据时，运行下面的代码可加载数组。
from joblib import dump, load
loaded_array = load('big_array.joblib')
























